const { MongoClient } = require('mongodb');
const faker = require("faker");
// or as an es module:
// import { MongoClient } from 'mongodb'

// Connection URL
const url = 'mongodb://localhost:27017';
const client = new MongoClient(url);

// Database Name
const dbName = 'Blogs';

async function main() {
  // Use connect method to connect to the server
  await client.connect();
  console.log('Connected successfully to server');
  const db = client.db(dbName);
  const collection = db.collection('users');
  const backup = db.collection('users_backup');


//   const usersArray = [];

//   for (let i =0; i< 50; i++){
//     usersArray.push({
//         name : faker.name.findName(),
//         email: faker.internet.email(),
//         age: Math.ceil(Math.random() *100), 
//         password : faker.datatype.string()
//     })
//   }

//   console.log(usersArray);

//   const data = await collection.insertMany(usersArray).toArray();

   const data = await collection.find().toArray();


//   const res = await backup.insertMany(data);

// const data = await collection.find({age : {$gt : 50}}).toArray();

//   const response =  await collection.updateMany({age : {$lt : }}, {$set : {minor : true}});

//  const response = await collection.deleteMany({age: {$gte :65}});
  console.log(res);
  // the following code examples can be pasted here...

  return 'done.';
}

main()
  .then(console.log)
  .catch(console.error)
  .finally(() => client.close());