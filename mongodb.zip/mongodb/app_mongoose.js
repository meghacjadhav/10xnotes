const mongoose = require("mongoose");
const faker = require("faker");
// or as an es module:
// import { MongoClient } from 'mongodb'
// Database Name
const dbName = 'Blogs';

async function main() {
  // Use connect method to connect to the server
  await mongoose.connect('mongodb://localhost/Blogs_mongoose');
  console.log('Connected successfully to server');

  const Schema = mongoose.Schema;
  const ObjectId = Schema.ObjectId;
  
  const UserSchema = new Schema({
    name : { type: String, required: true},
    email : { type : String, unique : true},
    age : Number,
    password : String,
    minor : Boolean
  });

  const users = mongoose.model('User', UserSchema);

  const BlogSchema = new Schema({
    title : {type: String, required: true },
    body: {type : String, required: true},
    user: {type: ObjectId, ref: "User"}
  });

  const blogsC = mongoose.model('Blogs', BlogSchema);


  const usersArray = [];

  // for (let i =0; i< 50; i++){
  //   usersArray.push({
  //       name : faker.name.findName(),
  //       email: faker.internet.email(),
  //       age: Math.ceil(Math.random() *100), 
  //       password : faker.datatype.string()
  //   })
  // }

  //  const user =  await users.create({
  //     name : "Ananad",
  //     email: "Ananad@gmail.com",
  //     age:22
  //  });

  // //  console.log(user);

  //  const blogsArray = [];
  //  for (let i =0; i<3; i++) {
  //     blogsArray.push({
  //       title: faker.lorem.word(), 
  //       body: faker.lorem.sentence(),
  //       user : user._id
  //     }) 
  //  }

  // const blogs = await blogsC.create(blogsArray);

  
  const blogsData = await blogsC.find().populate("user")
  console.log(blogsData);
  return 'done.';
}

main()
  .then(console.log)
  .catch(console.error)
  .finally(() => mongoose.disconnect());