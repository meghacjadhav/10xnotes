const {add} = require("./oper");

console.log("Hello Welcome to nodejs");


console.log(add(10,5));
console.log(sub(10,5));
// console.log(name);
// console.log(sub(10,5));
// console.log(mult(10,5));