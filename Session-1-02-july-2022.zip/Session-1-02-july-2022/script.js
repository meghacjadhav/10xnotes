//create element
//store reference
//set attributes-->optional
//set content/innerHTML
//append
//For Dynamic Styling

//understnd problem statement
//understand what parameters required
//undestand the logic and complexity
//undestand the return value

/*



var count=0;


const span=document.createElement("span");
setAttributes(span, {
"class": "date",
"id": "message",
"data-mymessage":"hi"});

setInterval(function(){//repeatative operation
    span.innerHTML=new Date().toLocaleTimeString();


    document.querySelector(".count").innerHTML=count;
count++;


}, 1000)
const container=document.querySelector(".container");
container.appendChild(span);

setTimeout(function(){//delay
    const random=document.querySelectorAll(".random");
    for (let ele of random){
ele.style.fontSize="20px";
ele.style.backgroundColor="green";
ele.classList.add("highlight");
    }
},10000)

function setAttributes(tag, attributes){
Object.keys(attributes).forEach(function(ele){
    tag.setAttribute(ele, attributes[ele]);
});
}
*/

//STOP Watch CODE

//get html node reference
//need to add event listner with type of event
//add callback handler
//unbind the event

let ms = 0,
  sec = 0,
  min = 0;

function timer() {
  //Get all DOM nodes
  const timer = document.querySelector(".timer");
  const start = document.querySelector(".start");
  const stop = document.querySelector(".stop");
  const reset = document.querySelector(".reset");

  let timerInterval;

  const startClickCallback = function (event) {
    console.log("Click event", event);

    timerInterval = setInterval(() => {
      ms++;
      if (ms >= 100) {
        sec++;
        ms = 0;
      }
      if (sec === 60) {
        min++;
        sec = 0;
      }
      if (min === 60) {
        ms, sec, (min = 0);
      }

      let milli = ms < 10 ? "0" + ms : ms;
      let seconds = sec < 10 ? "0" + sec : sec;
      let minutes = min < 10 ? "0" + min : min;
      timer.innerHTML = `${minutes}:${seconds}:${milli}`;
    }, 10);
  };

  const stopClickCallback = function (event) {
    clearInterval(timerInterval);
  };

  const resetClickCallback = function (event) {
if(confirm("Are you sure you want to reset")){
    stop.click();
    ms = 0;
    sec = 0;
    min = 0;
    timer.innerHTML = `00:00:00`;
}
else {
    stop.click();
}


  
  };

  start.addEventListener("click", startClickCallback);
  stop.addEventListener("click", stopClickCallback);
  reset.addEventListener("click", resetClickCallback);
}

timer();











/*
keydown
change
keyup
mouseover
mouseout
scroll
blur

*/

//GET Value from TEXTBOX change

(function(){
    debugger
    const input=document.querySelector(".text-input");
    const message=document.querySelector(".message");
    let isEventRemoved=true;
    const valueChangeHandler=function(event){
        if(isEventRemoved){
            message.innerHTML=input.value;
    
        }
    }
    
    input.addEventListener("keyup", valueChangeHandler);
    
    
    setTimeout(()=>{
        isEventRemoved=true;
        message.innerHTML="";
    input.removeEventListener("keyup", function(){})
    },10000)
})()



